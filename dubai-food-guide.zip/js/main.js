function renderRestaurants(list) {
const container = document.getElementById("restaurantList");
container.innerHTML = "";
list.forEach(r => {
container.innerHTML += `
<div class="card">
<img src="${r.image}">
<div class="card-content">
<h3>${r.name}</h3>
<p>Cuisine: ${r.cuisine}</p>
<p>Rating: ${r.rating}</p>
<p>${r.reviews}</p>
<p><strong>Today's Special:</strong> ${r.special}</p>
<p><strong>Hours:</strong> ${r.hours}</p>
<button onclick="openMaps(${r.lat}, ${r.lng})">Get Directions</button>
</div>
</div>`;
});
}

function filterCuisine() {
const value = document.getElementById("cuisineFilter").value;
if (value === "all") renderRestaurants(restaurants);
else renderRestaurants(restaurants.filter(r => r.cuisine === value));
}

renderRestaurants(restaurants);
