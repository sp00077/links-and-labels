function initMap() {
const dubai = { lat: 25.2048, lng: 55.2708 };
const map = new google.maps.Map(document.getElementById("map"), {
zoom: 11,
center: dubai
});

restaurants.forEach(r => {
new google.maps.Marker({
position: { lat: r.lat, lng: r.lng },
map: map,
title: r.name
});
});
}

function openMaps(lat, lng) {
window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`);
}

window.onload = initMap;
