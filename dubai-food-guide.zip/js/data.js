const restaurants = [
{
name: "Al Fanar Restaurant",
cuisine: "Emirati",
rating: "4.3⭐",
reviews: "Authentic Emirati dining experience",
lat: 25.2132,
lng: 55.2755,
hours: "9 AM - 11 PM",
special: "Chicken Machboos",
image: "images/sample-food.jpg"
},
{
name: "Ravi Restaurant",
cuisine: "Street Food",
rating: "4.2⭐",
reviews: "Legendary Pakistani street food",
lat: 25.2401,
lng: 55.2878,
hours: "10 AM - 12 AM",
special: "Chicken Biryani",
image: "images/sample-food.jpg"
}
];
